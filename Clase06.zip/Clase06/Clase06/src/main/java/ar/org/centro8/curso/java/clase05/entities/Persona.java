package ar.org.centro8.curso.java.clase05.entities;

public abstract class Persona {
    private String nombre;
    private int edad;
    private Direccion direccion;
    
    public Persona(String nombre, int edad, Direccion direccion) {
        this.nombre = nombre;
        this.edad = edad;
        this.direccion = direccion;
    }

    //public void saludar(){
    //    System.out.println("Hola soy una persona");
    //}

    public abstract void saludar();

    @Override
    public String toString() {
        return "Persona [direccion=" + direccion + ", edad=" + edad + ", nombre=" + nombre + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    
}
