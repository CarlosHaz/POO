package ar.org.centro8.curso.java.clase05.test;

import ar.org.centro8.curso.java.clase05.entities.Cliente;
import ar.org.centro8.curso.java.clase05.entities.Cuenta;
import ar.org.centro8.curso.java.clase05.entities.Direccion;
import ar.org.centro8.curso.java.clase05.entities.Persona;
import ar.org.centro8.curso.java.clase05.entities.Vendedor;

public class TestHerencia {
    
    /** 
     * @param args
     */
    public static void main(String[] args) {
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Medrano",161,"1","a","Moron");
        System.out.println(dir1);

        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Lima",200,"2","b");
        System.out.println(dir2);

        /*
            Clases Abstractas: son clases que no se pueden instanciar, es
            decir no se pueden crear objetos de la clase, si de clases hijas.

            Una clase final, es una clase que no puede tener clases hijas.
                Si se pueden crear objetos de la clase final.

            Métodos Abstractos: son métodos que no tienen cuerpo, es decir
                que no tienen código, solo pueden existir en clases abstractas,
                Las clases que heredan deben implementar los métodos abstractos.


        */

        /*
        System.out.println("-- persona1 --");
        Persona p1=new Persona("Karina",38,dir1);
        System.out.println(p1);
        p1.saludar();

        System.out.println("-- persona2 --");
        Persona p2=new Persona("Laura",26,p1.getDireccion());
        System.out.println(p2);
        p2.saludar();
        */

        System.out.println("-- v1 --");
        Vendedor v1=new Vendedor("Eliana", 29, dir2, 1, 90000);
        System.out.println(v1);
        v1.saludar();
        
        System.out.println("-- v2 --");
        Vendedor v2=new Vendedor("Debora", 23, new Direccion("lima",22,"1","a"), 2, 150000);
        System.out.println(v2);
        v2.saludar();
        
        System.out.println("-- cuenta1 --");
        Cuenta cuenta1=new Cuenta(1,"arg$");
        cuenta1.depositar(50000);
        cuenta1.depositar(80000);
        cuenta1.debitar(20000);
        System.out.println(cuenta1);

        System.out.println("-- cuenta2 --");
        Cuenta cuenta2=new Cuenta(2,"arg$");
        cuenta2.depositar(100000);
        cuenta2.debitar(50000);
        System.out.println(cuenta2);

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente("Joaquin",38,dir1,1,cuenta1);
        System.out.println(cliente1);
        cliente1.saludar();

        System.out.println("-- cliente2 --");
        Cliente cliente2=new Cliente("Sergio",39,dir2,2,cuenta2);
        System.out.println(cliente2);
        cliente2.saludar();

        System.out.println(cliente1.getClass());
        System.out.println(cliente1.getClass().getName());
        System.out.println(cliente1.getClass().getSimpleName());
        System.out.println(cliente1.getClass().getSuperclass().getName());
        System.out.println(cliente1
                                .getClass()
                                .getSuperclass()
                                .getSuperclass()
                                .getName());
        System.out.println(cliente1.getClass().getSuperclass().getSuperclass().getSuperclass());
        System.out.println("".getClass().getName());
        System.out.println("".getClass().getSuperclass().getName());

        Object obj=2;
        obj="hola";
        obj=cliente1;


        // Polimorfismo         Poliformismo

        Persona p1=new Vendedor("Diego", 22, dir2, 4, 50000);
        Persona p2=new Cliente("Maria",22,dir1,4,cuenta2);

        p1.saludar();
        p2.saludar();

        //Operador de casteo
        Vendedor vx=(Vendedor)p1;
        Vendedor vy=(p1 instanceof Vendedor)?(Vendedor)p1:null;
        

        // Temas pendientes
        // 1er Trabajo practico (abrir planillas y fecha de entrega)
        // Interfaces
        // Polimorfismo con interfaces
        // Class.forName y meta programación
        // Api reflect



    }
}
