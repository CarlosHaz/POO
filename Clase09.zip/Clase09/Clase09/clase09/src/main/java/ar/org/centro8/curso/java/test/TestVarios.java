package ar.org.centro8.curso.java.test;

import java.util.Scanner;

public class TestVarios {

    //reset de colores
    public static final String ANSI_RESET = "\u001B[0m";

    //colores de consola
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    

    //Colores de fondo
    public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
    public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
    public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
    public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
    public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
    public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
    public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
    public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";

    public static void main(String[] args) throws Exception {
        
        // Clase java.lang.Object
        /*
            Clase Object: es la clase padre o superclases de todas las clases,
                es un contenedor global.
                En el interior de la clase Object se define un comportamiento
                que es heredado a todos los objetos.
        */

        Object obj=new Object();

        //Clase Interna (Inner Class)
        class Dato{
            int dato;

            public Dato(int dato) {
                this.dato = dato;
            }

            @Override
            public String toString() {
                return "Dato [dato=" + dato + "]";
            }

            @Override
            public int hashCode() {
                return toString().hashCode();
            }

            @Override
            public boolean equals(Object obj) {
                if(obj==null) return false;
                return this.hashCode()==obj.hashCode();
            }
            
        }

        Dato d1=new Dato(2);
        Dato d2=d1;
        Dato d3=new Dato(d1.dato);
        Dato d4=new Dato(4);
        String d5="2";

        // método hashCode()
        System.out.println("d1.hashCode()= "+d1.hashCode());
        System.out.println("d2.hashCode()= "+d2.hashCode());
        System.out.println("d3.hashCode()= "+d3.hashCode());
        System.out.println("d4.hashCode()= "+d4.hashCode());
        System.out.println("d5.hashCode()= "+d5.hashCode());
        
        // métodos equals()
        System.out.println("d1.equals(d1)= "+d1.equals(d1));
        System.out.println("d1.equals(d2)= "+d1.equals(d2));
        System.out.println("d1.equals(d3)= "+d1.equals(d3));
        System.out.println("d1.equals(d4)= "+d1.equals(d4));
        System.out.println("d1.equals(d5)= "+d1.equals(d5));

        //System.out.println("Ingrese 'hola'");
        //String hola=new Scanner(System.in).next();
        //System.out.println("hola"==hola);
        //System.out.println("hola".equals("hola"));


        // Clase java.lang.System
        // Representa el entorno de ejecución de java.

        // Atributos staticos out err in

        // out: representa un stream de salida sincronizado a la consola
        // err: representa un stream de salida no sincronizado a la consola
        // in: representa un stream de entrada de datos sincronizado

        System.out.println("Mensaje de texto número 1");
        System.out.println("Mensaje de texto número 2");
        System.out.println("Mensaje de texto número 3");
        System.out.println("Mensaje de texto número 4");
        System.out.println("Mensaje de texto número 5");
        System.out.println("Mensaje de texto número 6");
        System.out.println("Mensaje de texto número 7");
        System.out.println("Mensaje de texto número 8");
        System.out.println("Mensaje de texto número 9");
        System.out.println("Mensaje de texto número 10");
        System.out.println("Mensaje de texto número 11");
        System.out.println("Mensaje de texto número 12");
        System.out.println("Mensaje de texto número 13");
        System.out.println("Mensaje de texto número 14");
        System.out.println("Mensaje de texto número 15");
        System.out.println("Mensaje de texto número 16");
        System.out.println("Mensaje de texto número 17");
        System.out.println("Mensaje de texto número 18");
        System.out.println("Mensaje de texto número 19");
        System.out.println("Mensaje de texto número 20");
        System.err.println("Ocurrio un error!");

        // Colores en consola

        /*
        public static final String ANSI_BLACK = "\u001B[30m";
        public static final String ANSI_RED = "\u001B[31m";
        public static final String ANSI_GREEN = "\u001B[32m";
        public static final String ANSI_YELLOW = "\u001B[33m";
        public static final String ANSI_BLUE = "\u001B[34m";
        public static final String ANSI_PURPLE = "\u001B[35m";
        public static final String ANSI_CYAN = "\u001B[36m";
        public static final String ANSI_WHITE = "\u001B[37m";
        public static final String ANSI_RESET = "\u001B[0m";
        */

        System.out.println(ANSI_CYAN_BACKGROUND+ANSI_RED+"Hola a todos"+ANSI_RESET);

        //metodo .exit(int x)
        //método estatico que cierra el runtime (Apaga el programa)
        // x es la devolución de error al SO
        //System.exit(0);
        //System.out.println("Esta linea no se ejecuta!!!");

        // .getProperties()
        System.out.println(System.getProperties());

        String[] propiedades= System.getProperties().toString().split(",");
        for(int a=0; a<propiedades.length; a++) System.out.println(propiedades[a]);

        System.out.println("****************************************************");
        System.out.println(System.getProperty("user.name"));
        System.out.println(System.getProperty("user.home"));
        System.out.println(System.getProperty("user.languaje"));
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("java.version"));
        
        // .getEnv()
        System.out.println(System.getenv());
        propiedades= System.getenv().toString().split(",");
        for(int a=0; a<propiedades.length; a++) System.out.println(propiedades[a]);

        System.out.println("****************************************************");
        System.out.println(System.getenv("DESKTOP_SESSION"));

        System.out.println("Cantidad de procesadores: "+Runtime.getRuntime().availableProcessors());

        //Runtime.getRuntime().exec("clear");

        // Clase java.lang.String
        String texto1="hola";
        String texto2=new String("hola");
        char[] vector={'h','o','l','a'};
        String texto3=new String(vector);

        //.trim()
        System.out.println("   hola   ".trim());

        //.startsWith() .endsWith()
        System.out.println(texto1.startsWith("h"));
        System.out.println(texto1.endsWith("o"));
        
        //.containt()
        System.out.println(texto1.contains("x"));

        //.charAt()
        System.out.println(texto1.charAt(2));

        //.subString
        System.out.println(texto1.substring(2));

        //.equals() .equalsIgnoreCase()
        System.out.println(texto1.equalsIgnoreCase("HOLA"));

        //.toLowerCase() .toUpperCase()
        System.out.println(texto1.toLowerCase());
        System.out.println(texto1.toUpperCase());

        


    }
}
