package ar.org.centro8.curso.java.clase11.entities;

import java.text.DecimalFormat;

public class Persona implements Comparable<Persona> {
    private String nombre;
    private String apellido;
    private int edad;
    
    public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Persona [apellido=" + apellido + ", edad=" + edad + ", nombre=" + nombre + "]";
    }


    @Override
    public int compareTo(Persona para) {
        // garcia,ana,009
        // garcia,ana,012
        // ###,###,###.00   dos decimales y separador de miles

        DecimalFormat df=new DecimalFormat("000");
        String thisPersona = (this.getApellido()+","+this.getNombre()+","+df.format(this.getEdad())).toLowerCase();
        String paraPersona = (para.getApellido()+","+para.getNombre()+","+df.format(para.getEdad())).toLowerCase();
        //return thisPersona.compareTo(paraPersona)*-1;
        return thisPersona.compareTo(paraPersona);
    }

    @Override
    public int hashCode() {
        return toString().hashCode();
    }

    @Override
    public boolean equals(Object obj) {
       if(obj==null) return false;
       return this.hashCode()==obj.hashCode();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

}
