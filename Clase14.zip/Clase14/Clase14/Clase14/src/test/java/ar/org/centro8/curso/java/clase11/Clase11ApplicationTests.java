package ar.org.centro8.curso.java.clase11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
