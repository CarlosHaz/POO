package ar.org.centro8.curso.java.test;

public class GeneradorExceptions {
    public static void generar(){
        int[] vector=new int[5];
        vector[10]=20;
    }

    public static void generar(boolean x){
        if(x) System.out.println(10/0);
    }

    public static void generar(String nro){         // "38x"
        int numero=Integer.parseInt(nro);
    }

    public static void generar(String text, int index){     // "hola",20
        //if(text==null || index<0 || index>=text.length()) return;
        System.out.println(text.charAt(index));
    }
}


