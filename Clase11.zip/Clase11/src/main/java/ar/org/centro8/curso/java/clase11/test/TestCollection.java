package ar.org.centro8.curso.java.clase11.test;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import javax.sound.midi.Soundbank;
import javax.swing.plaf.basic.BasicInternalFrameTitlePane.SystemMenuBar;

import org.springframework.util.SocketUtils;

import ar.org.centro8.curso.java.clase11.entities.Persona;

public class TestCollection {
    public static void main(String[] args) {

        // Collecciones
        Persona[] personas = new Persona[4];
        personas[0] = new Persona("Javier", "Costa", 34);
        personas[1] = new Persona("Lorena", "Gomez", 38);
        personas[2] = new Persona("Horacio", "Mendez", 29);
        personas[3] = new Persona("Eliana", "Correa", 39);

        // Recorrido por indices
        // for(int a=0;a<personas.length;a++){
        // System.out.println(personas[a]);
        // }

        // Recorrido forEach JDK 5
        // for(Persona persona : personas) System.out.println(persona);

        Arrays.asList(personas).forEach(System.out::println);

        // Interface List
        // Representa una lista dinamica tipo vector con indices

        List list;
        list = new ArrayList(); // Lista Dinamica
        // list=new LinkedList();
        // list=new Vector();

        list.add(new Persona("Gabriel", "Bando", 45)); // 0
        list.add(new Persona("Fernando", "Tigo", 39)); // 2
        list.add("Hola"); // 3
        list.add(22); // 4
        list.add("Chau"); // 5
        list.add(1, "Miércoles"); // 1
        // list.remove(5);

        System.out.println("****************************************");
        // Recorrido con indices
        // for(int a=0;a<list.size();a++) System.out.println(list.get(a));

        // Recorrido forEach
        // for(Object o:list) System.out.println(o);

        // método forEach() JDK 8 o superior
        // Lambda Expression jdk 8 sup
        // list.forEach(o->System.out.println(o));
        // list.forEach(o->{
        // System.out.println(o);
        // });

        list.forEach(System.out::println);

        // Pendientes
        // Uso de Generics <> JDK 5 o sup.

        List<Persona> list2 = new ArrayList<Persona>();

        list2.add(new Persona("juan", "Morales", 23));

        Persona p1 = (Persona) list.get(0);
        Persona p2 = list2.get(0);

        // copiar las personas del vector personas a list2
        for (Persona p : personas)
            list2.add(p);
        list2.addAll(Arrays.asList(personas));

        // copiar personas de list a list2

        list.forEach(o -> {
            if (o instanceof Persona)
                list2.add((Persona) o);
        });
        //
        System.out.println("*************");
        list2.forEach(System.out::println);

        // InterfaceSet
        Set<String> set;

        // Implementacion HAshSet: alamacena y recupera elementos de la forma
        // mas veloz posible, no garantiza el orden de los elementos.

        // set=new HashSet();

        // Implementacion LinkedHashset;: almacena elementos en una lista
        // enlazada por orden de ingreso
        // set=new LinkedHashSet();

        // Implementacion TreeSet: Almacena elementos en un arbol por orden natural
        set = new TreeSet();

        set.add("lunes");
        set.add("martes");
        set.add("miercoles");
        set.add("jueves");
        set.add("viernes");
        set.add("sabado");
        set.add("sabado");
        set.add("domingo");
        set.add("lunes");
        set.add("lunes");
        set.forEach(System.out::println);

        Set<Persona> setPersonas;

        // setPersonas=new LinkedHashSet();
        setPersonas = new TreeSet();
        setPersonas.addAll(list2);
        setPersonas.add(new Persona("Juan", "Morales", 23));
        setPersonas.add(new Persona("Victor", "Morales", 33));
        setPersonas.add(new Persona("Ana", "Morales", 43));
        setPersonas.add(new Persona("Beatriz", "Morales", 53));
        setPersonas.add(new Persona("Carlos", "Morales", 63));

        System.out.println("*************");
        setPersonas.forEach(p -> System.out.println(p + " " + p.hashCode()));

        // Interface Comparable

        // Pilas Colas
        // Maps
        // API Stream

    }
}
