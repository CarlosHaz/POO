package ar.org.centro8.curso.java.clase11.test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.Arrays;

import ar.org.centro8.curso.java.clase11.entities.Persona;

public class TestReflect {
    public static void main(String[] args) throws Exception {
        // Clase 11
        //Api Stream

        Object o=new Persona("Ana", "Salas", 26);

        System.out.println(o.getClass());
        System.out.println(o.getClass().getName());
        System.out.println(o.getClass().getSimpleName());
        System.out.println(o.getClass().getSuperclass().getName());

        //campos de la clase
        Field[] campos=o.getClass().getDeclaredFields();
        for(int a=0;a<campos.length;a++){
            System.out.println("------------------------------------------");
            System.out.println(campos[a]);
            System.out.println(campos[a].getType().getName());
            System.out.println(campos[a].getModifiers());
            System.out.println(campos[a].getName());
        }

        //campos de la clase + campos heredados
        campos=o.getClass().getFields();
        for(int a=0;a<campos.length;a++){
            System.out.println("------------------------------------------");
            System.out.println(campos[a]);
            System.out.println(campos[a].getType().getName());
            System.out.println(campos[a].getModifiers());
            System.out.println(campos[a].getName());
        }

        //métodos de la clase
        Method[] metodos=o.getClass().getDeclaredMethods();
        for(int a=0;a<metodos.length;a++){
            System.out.println("------------------------------------------");
            System.out.println(metodos[a]);
            System.out.println(metodos[a].getName());
            System.out.println(metodos[a].getModifiers());
            System.out.println(metodos[a].getReturnType().getName());
            Parameter[] parametros=metodos[a].getParameters();
            System.out.println("Parametros de entrada:");
            for(int x=0;x<parametros.length;x++){
                System.out.println(parametros[x]);
            }
        }

        //métodos de la clase + métodos heredados
        metodos=o.getClass().getMethods();
        for(int a=0;a<metodos.length;a++){
            System.out.println("------------------------------------------");
            System.out.println(metodos[a]);
            System.out.println(metodos[a].getName());
            System.out.println(metodos[a].getModifiers());
            System.out.println(metodos[a].getReturnType().getName());
            Parameter[] parametros=metodos[a].getParameters();
            System.out.println("Parametros de entrada:");
            for(int x=0;x<parametros.length;x++){
                System.out.println(parametros[x]);
            }
        }

        //Constructores de la clase
        Constructor[] constructores=o.getClass().getConstructors();
        for(int a=0;a<constructores.length;a++){
            System.out.println(constructores[a]);
        }

        //invokar un método de la clase
        System.out.println(
            o
                .getClass()
                .getMethod("getApellido")
                .invoke(o)
        );

        System.out.println("*****************************");
        Arrays
            .asList(
                o
                .getClass()
                .getDeclaredFields())
                .forEach(System.out::println);

    }
}
