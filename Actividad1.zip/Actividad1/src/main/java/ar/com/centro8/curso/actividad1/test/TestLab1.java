package ar.com.centro8.curso.actividad1.test;

import ar.com.centro8.curso.actividad1.entities.Auto;
import ar.com.centro8.curso.actividad1.entities.AutoClasico;
import ar.com.centro8.curso.actividad1.entities.AutoNuevo;
import ar.com.centro8.curso.actividad1.entities.Radio;

public class TestLab1 {
    public static void main(String[] args) {

        System.out.println("- Radio1 -");
        Radio Radio1 = new Radio("Pioneer");
        System.out.println(Radio1);

        System.out.println("- Radio2 -");
        Radio radio2 = new Radio("Sony");
        System.out.println(radio2);

        System.out.println("- Radio3 -");
        Radio Radio3 = new Radio("JBL");
        System.out.println(Radio3);

        System.out.println("- Auto1 -");
        Auto auto1 = new Auto("Volkswagen", "Polo", "Verde", 1600000);
        auto1.setRadio("Sony");
        System.out.println(auto1);

        System.out.println("- Acl1 -");
        AutoClasico ac1 = new AutoClasico("Ferrari", "Spider", "Rojo");
        ac1.setRadio("JBL");
        System.out.println(ac1);

        System.out.println("- Acl2 -");
        AutoClasico ac2 = new AutoClasico("Toyota", "Machito", "Blanco", 2300000);
        ac2.setRadio("Panasonic");
        System.out.println(ac2);

        System.out.println("- Anw1 -");
        AutoNuevo an1 = new AutoNuevo("Chevrolet", "Agile", "Blanco", "JVC");
        an1.setRadio("JVC");
        System.out.println(an1);

        System.out.println("- Anw2 -");
        AutoNuevo an2 = new AutoNuevo("Honda", "Fit", "Gris", 800000, "Panasonic");
        an2.setRadio("Sony");
        System.out.println(an2);
    }
}
