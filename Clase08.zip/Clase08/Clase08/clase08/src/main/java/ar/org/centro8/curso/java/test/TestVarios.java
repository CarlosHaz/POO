package ar.org.centro8.curso.java.test;

public class TestVarios {
    public static void main(String[] args) {
        
        // Clase java.lang.Object
        /*
            Clase Object: es la clase padre o superclases de todas las clases,
                es un contenedor global.
                En el interior de la clase Object se define un comportamiento
                que es heredado a todos los objetos.
        */

        Object obj=new Object();

        //Clase Interna (Inner Class)
        class Dato{
            int dato;

            public Dato(int dato) {
                this.dato = dato;
            }
            
        }

        Dato d1=new Dato(2);
        Dato d2=d1;
        Dato d3=new Dato(d1.dato);
        Dato d4=new Dato(4);
        String d5="2";

        // método hashCode()
        System.out.println("d1.hashCode()= "+d1.hashCode());
        System.out.println("d2.hashCode()= "+d2.hashCode());
        System.out.println("d3.hashCode()= "+d3.hashCode());
        System.out.println("d4.hashCode()= "+d4.hashCode());
        System.out.println("d5.hashCode()= "+d5.hashCode());
        
        // Clase java.lang.System


        // Clase java.lang.String



    }
}
