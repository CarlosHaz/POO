package ar.org.centro8.curso.java.clase11.test;


import java.util.ArrayDeque;

//import java.util.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import ar.org.centro8.curso.java.clase11.entities.Persona;

public class TestCollection {
    public static void main(String[] args) {
        
        
        //Collecciones
        Persona[] personas=new Persona[4];
        personas[0]=new Persona("Javier","Costa",34);
        personas[1]=new Persona("Lorena","Gomez",38);
        personas[2]=new Persona("Horacio","Mendez",29);
        personas[3]=new Persona("Eliana","Correa",39);

        //Recorrido por indices
        //for(int a=0;a<personas.length;a++){
        //    System.out.println(personas[a]);
        //}

        //Recorrido forEach JDK 5
        //for(Persona persona : personas) System.out.println(persona);

        Arrays.asList(personas).forEach(System.out::println);

        //Interface List
        //Representa una lista dinamica tipo vector con indices

        List list;
        list=new ArrayList();       //Lista Dinamica
        //list=new LinkedList();
        //list=new Vector();

        list.add(new Persona("Gabriel", "Bando", 45));          // 0
        list.add(new Persona("Fernando", "Tigo", 39));          // 2
        list.add("Hola");                                       // 3
        list.add(22);                                           // 4
        list.add("Chau");                                       // 5
        list.add(1, "Miércoles");                               // 1
        //list.remove(5);

        System.out.println("****************************************");
        //Recorrido con indices
        //for(int a=0;a<list.size();a++) System.out.println(list.get(a));

        //Recorrido forEach
        //for(Object o:list) System.out.println(o);
 
        //método forEach() JDK 8 o superior
        //Lambda Expression jdk 8 sup 
        //list.forEach(o->System.out.println(o));
        //list.forEach(o->{
        //    System.out.println(o);
        //});

        list.forEach(System.out::println);


        //Pendientes
        // Uso de Generics <> JDK 5 o sup.
        List<Persona>list2=new ArrayList();
        
        list2.add(new Persona("Juan", "Morales", 23));

        Persona p1=(Persona)list.get(0);
        Persona p2=list2.get(0);

        //copiar las personas del vector personas a list2
        //for(Persona p:personas) list2.add(p);
        list2.addAll(Arrays.asList(personas));

        //copiar las personas de list a list2
        list.forEach(o->{
            if(o instanceof Persona) list2.add((Persona)o);
        });

        System.out.println("**************************************");
        list2.forEach(System.out::println);

        // Interface Set
        Set<String> set;
        
        // Implementación HashSet: Almacena y recupera elementos de la 
        //      forma más veloz posible, no garantiza el orden de los elementos
        //set=new HashSet();


        // Implementación LinkedHashSet: Almacena elementos en una lista
        //      enlazada por orden de ingreso
        //set=new LinkedHashSet();
        
        // Implementación TreeSet: Almacena elementos en un arbol
        //      por orden natural.
        set=new TreeSet();

        set.add("lunes");
        set.add("martes");
        set.add("miércoles");
        set.add("jueves");
        set.add("viernes");
        set.add("sábado");
        set.add("sábado");
        set.add("domingo");
        set.add("lunes");
        set.add("lunes");
        set.forEach(System.out::println);

        Set<Persona> setPersonas;

        //setPersonas=new LinkedHashSet();
        setPersonas=new TreeSet();
        setPersonas.addAll(list2);
        setPersonas.add(new Persona("Juan","Morales",23));
        setPersonas.add(new Persona("Victor","Morales",23));
        setPersonas.add(new Persona("Ana","Morales",23));
        setPersonas.add(new Persona("Beatriz","Morales",23));
        setPersonas.add(new Persona("Carlos","Morales",23));
        setPersonas.add(new Persona("Carlos","Morales",9));

        System.out.println("*******************************************");
        //setPersonas.forEach(System.out::println);
        setPersonas.forEach(p->System.out.println(p+" "+p.hashCode()));

        // Interface Comparable



        // Pilas Colas
        
        /*
            Pilas LIFO Last In First Out
            Clase Stack

            Colas FIFO First In First Out
            Interface Queue
        */

        // Clase Stack Pilas
        Stack<Persona>pilaPersona=new Stack();
        // método .push() permite apilar un elemento a la pila
        pilaPersona.push(new Persona("Malena", "Moroni", 23));
        pilaPersona.addAll(list2);

        System.out.println("****************************************");
        pilaPersona.forEach(System.out::println);
        System.out.println("****************************************");

        System.out.println("Longitud de pila: "+pilaPersona.size());
        while(!pilaPersona.isEmpty()){
            System.out.println(pilaPersona.pop());
            //método .pop() devuelve un elemento de la pila
        }
        
        System.out.println("Longitud de pila: "+pilaPersona.size());

        // Clase ArrayDeque Colas
        ArrayDeque<Persona> colaPersona=new ArrayDeque<>();
        colaPersona.offer(new Persona("Matias", "Torres", 26));
        // método offer() encola un elemento
        colaPersona.addAll(list2);

        System.out.println("****************************************");
        colaPersona.forEach(System.out::println);
        System.out.println("****************************************");
        
        System.out.println("Longitud de Cola: "+colaPersona.size());
        while(!colaPersona.isEmpty()){
            System.out.println(colaPersona.poll());
            // .poll() desencola un elemento.
        }

        System.out.println("Longitud de Cola: "+colaPersona.size());
        
        
        // Interface Map
        Map<String,String>mapaSemana=null;
        
        //Implementación Hashtable: es una implementación desordenada y veloz,
        //                          permite trabajas en hilos, se considera obsoleta o legacy
        //mapaSemana=new Hashtable();

        //Implementación HashMap:   Es la implementación más veloz, es desordenada.
        //                          no permite trabajar en hilos, no se considera obsoleta
        //mapaSemana=new HashMap();

        //Implementación LinkedHashMap: Almacena elementos en una lista ordenada por llave y 
        //                              por orden de ingreso.
        //mapaSemana=new LinkedHashMap();

        //Implementación TreeMap(); Almacena elementos en un arbol, ordenador por llava y 
        //                          orden natural
        mapaSemana=new TreeMap();

        mapaSemana.put("lu", "Lunes");
        mapaSemana.put("ma", "Martes");
        mapaSemana.put("mi", "Miércoles");
        mapaSemana.put("ju", "Jueves");
        mapaSemana.put("vi", "Viernes");
        mapaSemana.put("sa", "Sábado");
        mapaSemana.put("do", "Domingo");

        // mapaSemana.put("lu", "Monday");
        // mapaSemana.put("ma", "Tuesday");
        // mapaSemana.put("mi", "Wednesday");
        // mapaSemana.put("ju", "Thursday");
        // mapaSemana.put("vi", "Friday");
        // mapaSemana.put("sa", "Saturday");
        // mapaSemana.put("do", "Sunday");

        //mapaSemana.put("lu", "X");
        //mapaSemana.put("x", "martes");
        System.out.println(mapaSemana.get("vi"));
        mapaSemana.remove("lu");
        System.out.println("--------------------------------");
        mapaSemana.forEach((k,v)->System.out.println(k+" "+v));
        System.out.println("--------------------------------");
        //mapaSemana.keySet().forEach(mapaSemana::get);
        for(String st:mapaSemana.keySet()) System.out.println(mapaSemana.get(st));

        Map<Integer,Persona>mapaPersona=new LinkedHashMap();
        mapaPersona.put(-1, list2.get(1));
        mapaPersona.put(20, list2.get(2));
        mapaPersona.put(-30, list2.get(3));
        mapaPersona.put(40, list2.get(4));
        mapaPersona.put(56, list2.get(5));
        System.out.println(mapaPersona.get(-30));

        System.getProperties().forEach((k,v)->System.out.println(k+"\t\t"+v));
        System.getenv().forEach((k,v)->System.out.println(k+"\t\t"+v));

        
        // API Stream

        

    }
}
